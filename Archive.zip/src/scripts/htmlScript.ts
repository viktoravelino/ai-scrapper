import * as cheerio from "cheerio";
import fs from "fs";
import beautify from "js-beautify";

const url = "https://mui.com/joy-ui/react-button/";

export async function createData() {
  const response = await fetch(url);
  const htmlString = await response.text();

  const $ = cheerio.load(htmlString);

  const pageTitle = $("title").text();

  $("script").remove();
  $("head").remove();
  $("style").remove();

  // get the main tag
  const main = $("main");
  // remove all children of the main tag
  $("main").remove();
  // get the body tag
  const body = $("body");

  // get the children of the body tag
  const bodyElements = checkChildren($, body);
  // get the children of the main tag
  const mainElements = checkChildren($, main);

  // beautify the html
  const beautifiedHtml = beautify.html(bodyElements + mainElements, {
    indent_size: 2,
    inline: [], // don't inline any tags
  });

  const docLines = beautifiedHtml
    .replace(/<\/[^>]+>/g, "") // remove all closing tags
    .split("\n") // create an array of lines
    .filter((line) => line.trim().length > 0); // remove all empty lines

  const docs = docLines.map((line) => ({
    metadata: {
      source: url,
      content: "HTML Element",
    },
    pageContent: line.trim(),
  }));

  fs.writeFileSync(
    "src/data.ts",
    `export const data = ${JSON.stringify(docs, null, 2)}`
  );
}

// crazy recursive function to get the html of the children of the element
function checkChildren(
  $: cheerio.CheerioAPI,
  el: cheerio.Cheerio<cheerio.Element>
) {
  if (el.children().length === 1) {
    return checkChildren($, $(el.children()[0]));
  } else {
    return el.html() ?? "";
  }
}

createData();
