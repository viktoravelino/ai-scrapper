export const data = [
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-o7vfa5\" href=\"#main-content\">Skip to content"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<header class=\"MuiPaper-root MuiPaper-elevation MuiPaper-elevation4 MuiAppBar-root MuiAppBar-colorPrimary MuiAppBar-positionFixed mui-fixed css-1thp9i\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiToolbar-root MuiToolbar-dense css-mjywep\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorPrimary MuiIconButton-edgeStart MuiIconButton-sizeMedium css-1vpj8z7\" tabindex=\"0\" type=\"button\" aria-label=\"Open main navigation\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 16 16\" fill=\"none\" class=\"css-1170n61\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<rect x=\"1\" y=\"5\" width=\"14\" height=\"1.5\" rx=\"1\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<rect x=\"1\" y=\"9\" width=\"14\" height=\"1.5\" rx=\"1\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiBox-root css-9ms5j3\" aria-label=\"go to homepage\" href=\"/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"30\" height=\"32\" viewBox=\"0 0 36 32\" fill=\"none\" class=\"css-1170n61\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M30.343 21.976a1 1 0 00.502-.864l.018-5.787a1 1 0 01.502-.864l3.137-1.802a1 1 0 011.498.867v10.521a1 1 0 01-.502.867l-11.839 6.8a1 1 0 01-.994.001l-9.291-5.314a1 1 0 01-.504-.868v-5.305c0-.006.007-.01.013-.007.005.003.012 0 .012-.007v-.006c0-.004.002-.008.006-.01l7.652-4.396c.007-.004.004-.015-.004-.015a.008.008 0 01-.008-.008l.015-5.201a1 1 0 00-1.5-.87l-5.687 3.277a1 1 0 01-.998 0L6.666 9.7a1 1 0 00-1.499.866v9.4a1 1 0 01-1.496.869l-3.166-1.81a1 1 0 01-.504-.87l.028-16.43A1 1 0 011.527.86l10.845 6.229a1 1 0 00.996 0L24.21.86a1 1 0 011.498.868v16.434a1 1 0 01-.501.867l-5.678 3.27a1 1 0 00.004 1.735l3.132 1.783a1 1 0 00.993-.002l6.685-3.839zM31 7.234a1 1 0 001.514.857l3-1.8A1 1 0 0036 5.434V1.766A1 1 0 0034.486.91l-3 1.8a1 1 0 00-.486.857v3.668z\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-11qjisw\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-dj5l2h\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-caption MuiLink-root MuiLink-underlineNone css-1jgw86u\" href=\"https://tally.so/r/3Ex4PN?source=docs-banner\" target=\"_blank\">Influence Joy&nbsp;UI's 2024 roadmap! Participate in the latest Developer Survey"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-vx3hj7\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorPrimary MuiIconButton-sizeMedium css-afomzc\" tabindex=\"0\" href=\"https://github.com/mui/material-ui\" data-ga-event-category=\"header\" data-ga-event-action=\"github\" aria-label=\"GitHub repository\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"GitHubIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 1.27a11 11 0 00-3.48 21.46c.55.09.73-.28.73-.55v-1.84c-3.03.64-3.67-1.46-3.67-1.46-.55-1.29-1.28-1.65-1.28-1.65-.92-.65.1-.65.1-.65 1.1 0 1.73 1.1 1.73 1.1.92 1.65 2.57 1.2 3.21.92a2 2 0 01.64-1.47c-2.47-.27-5.04-1.19-5.04-5.5 0-1.1.46-2.1 1.2-2.84a3.76 3.76 0 010-2.93s.91-.28 3.11 1.1c1.8-.49 3.7-.49 5.5 0 2.1-1.38 3.02-1.1 3.02-1.1a3.76 3.76 0 010 2.93c.83.74 1.2 1.74 1.2 2.94 0 4.21-2.57 5.13-5.04 5.4.45.37.82.92.82 2.02v3.03c0 .27.1.64.73.55A11 11 0 0012 1.27\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorPrimary MuiIconButton-sizeMedium css-afomzc\" tabindex=\"0\" type=\"button\" aria-haspopup=\"true\" aria-label=\"0 unread notifications\" data-ga-event-category=\"AppBar\" data-ga-event-action=\"toggleNotifications\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiBadge-root css-1rzb3uu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"NotificationsNoneRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19.29 17.29 18 16v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-1.29 1.29c-.63.63-.19 1.71.7 1.71h13.17c.9 0 1.34-1.08.71-1.71M16 17H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5zm-4 5c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiBadge-badge MuiBadge-standard MuiBadge-invisible MuiBadge-anchorOriginTopRight MuiBadge-anchorOriginTopRightRectangular MuiBadge-overlapRectangular MuiBadge-colorError css-1xohf1j\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorPrimary MuiIconButton-sizeMedium css-1k36t8h\" tabindex=\"0\" type=\"button\" aria-label=\"Toggle settings drawer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"SettingsOutlinedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19.43 12.98c.04-.32.07-.64.07-.98 0-.34-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.09-.16-.26-.25-.44-.25-.06 0-.12.01-.17.03l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.06-.02-.12-.03-.18-.03-.17 0-.34.09-.43.25l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98 0 .33.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.09.16.26.25.44.25.06 0 .12-.01.17-.03l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.06.02.12.03.18.03.17 0 .34-.09.43-.25l2-3.46c.12-.22.07-.49-.12-.64zm-1.98-1.71c.04.31.05.52.05.73 0 .21-.02.43-.05.73l-.14 1.13.89.7 1.08.84-.7 1.21-1.27-.51-1.04-.42-.9.68c-.43.32-.84.56-1.25.73l-1.06.43-.16 1.13-.2 1.35h-1.4l-.19-1.35-.16-1.13-1.06-.43c-.43-.18-.83-.41-1.23-.71l-.91-.7-1.06.43-1.27.51-.7-1.21 1.08-.84.89-.7-.14-1.13c-.03-.31-.05-.54-.05-.74s.02-.43.05-.73l.14-1.13-.89-.7-1.08-.84.7-1.21 1.27.51 1.04.42.9-.68c.43-.32.84-.56 1.25-.73l1.06-.43.16-1.13.2-1.35h1.39l.19 1.35.16 1.13 1.06.43c.43.18.83.41 1.23.71l.91.7 1.06-.43 1.27-.51.7 1.21-1.07.85-.89.7zM12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4m0 6c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<nav class=\"css-byvrio\" aria-label=\"documentation\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiDrawer-root MuiDrawer-docked css-hpem8t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-wfjugg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-34y0es\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiBox-root css-1wzy1hs\" aria-label=\"go to homepage\" href=\"/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"30\" height=\"32\" viewBox=\"0 0 36 32\" fill=\"none\" class=\"css-1170n61\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M30.343 21.976a1 1 0 00.502-.864l.018-5.787a1 1 0 01.502-.864l3.137-1.802a1 1 0 011.498.867v10.521a1 1 0 01-.502.867l-11.839 6.8a1 1 0 01-.994.001l-9.291-5.314a1 1 0 01-.504-.868v-5.305c0-.006.007-.01.013-.007.005.003.012 0 .012-.007v-.006c0-.004.002-.008.006-.01l7.652-4.396c.007-.004.004-.015-.004-.015a.008.008 0 01-.008-.008l.015-5.201a1 1 0 00-1.5-.87l-5.687 3.277a1 1 0 01-.998 0L6.666 9.7a1 1 0 00-1.499.866v9.4a1 1 0 01-1.496.869l-3.166-1.81a1 1 0 01-.504-.87l.028-16.43A1 1 0 011.527.86l10.845 6.229a1 1 0 00.996 0L24.21.86a1 1 0 011.498.868v16.434a1 1 0 01-.501.867l-5.678 3.27a1 1 0 00.004 1.735l3.132 1.783a1 1 0 00.993-.002l6.685-3.839zM31 7.234a1 1 0 001.514.857l3-1.8A1 1 0 0036 5.434V1.766A1 1 0 0034.486.91l-3 1.8a1 1 0 00-.486.857v3.668z\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-i9gxme\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-1m0c3wt\">MUI&nbsp;Core"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-k008qs\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation css-1obm9qa\" tabindex=\"0\" type=\"button\" id=\"mui-product-selector\" aria-haspopup=\"true\">Joy&nbsp;UI<span class=\"MuiButton-endIcon MuiButton-iconSizeMedium css-pt151d\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1npej63\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ArrowDropDownRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"m8.71 11.71 2.59 2.59c.39.39 1.02.39 1.41 0l2.59-2.59c.63-.63.18-1.71-.71-1.71H9.41c-.89 0-1.33 1.08-.7 1.71\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-disableElevation css-9phpz7\" tabindex=\"0\" type=\"button\" id=\"mui-version-selector\">v5.0.0-beta.25"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-fullWidth css-10d9ljd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-pvq6oi\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1ew28kd\" href=\"/joy-ui/getting-started/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1upq9j4\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Getting started"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone algolia-lvl0 css-1ew28kd\" href=\"/joy-ui/react-autocomplete/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1c9jvr1\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Components"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Inputs"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-autocomplete/\">Autocomplete"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone app-drawer-active css-sssjjw\" href=\"/joy-ui/react-button/\">Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-button-group/\">Button Group"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-checkbox/\">Checkbox"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-input/\">Input"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-radio-button/\">Radio Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-select/\">Select"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-slider/\">Slider"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-switch/\">Switch"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-textarea/\">Textarea"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-text-field/\">Text Field"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-toggle-button-group/\">Toggle Button Group<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Data display"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-aspect-ratio/\">Aspect Ratio"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-avatar/\">Avatar"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-badge/\">Badge"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-chip/\">Chip"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-divider/\">Divider"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-list/\">List"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-table/\">Table"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-tooltip/\">Tooltip"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-typography/\">Typography"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Feedback"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-alert/\">Alert"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-circular-progress/\">Circular Progress"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-linear-progress/\">Linear Progress"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-modal/\">Modal"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-skeleton/\">Skeleton<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-snackbar/\">Snackbar<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Surfaces"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-accordion/\">Accordion<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-card/\">Card"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-sheet/\">Sheet"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Navigation"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-breadcrumbs/\">Breadcrumbs"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-drawer/\">Drawer<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-link/\">Link"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-menu/\">Menu"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-stepper/\">Stepper<div class=\"MuiChip-root MuiChip-filled MuiChip-sizeMedium MuiChip-colorDefault MuiChip-filledDefault css-1wv67ob\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelMedium css-14vsv3w\">New"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-tabs/\">Tabs"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Layout"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-box/\">Box"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-grid/\">Grid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-stack/\">Stack"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-as1hzh\">Utils"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiList-root MuiList-padding css-ebbka6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-l0ivs3\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-sssjjw\" href=\"/joy-ui/react-css-baseline/\">CSS Baseline"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1ew28kd\" href=\"/joy-ui/api/accordion/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1upq9j4\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "APIs"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1ew28kd\" href=\"/joy-ui/customization/approaches/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1upq9j4\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Customization"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1ew28kd\" href=\"/joy-ui/integrations/next-js-app-router/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1upq9j4\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Integrations"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li class=\"css-1c4kt1k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1ew28kd\" href=\"/joy-ui/migration/migrating-default-theme/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium ItemButtonIcon css-1upq9j4\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.29 15.88 13.17 12 9.29 8.12a.9959.9959 0 0 1 0-1.41c.39-.39 1.02-.39 1.41 0l4.59 4.59c.39.39.39 1.02 0 1.41L10.7 17.3c-.39.39-1.02.39-1.41 0-.38-.39-.39-1.03 0-1.42\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Migration"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"mui-fixed MuiBox-root css-1f23llj\" aria-label=\"Scroll to top\" style=\"opacity:0;visibility:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiFab-root MuiFab-circular MuiFab-sizeSmall MuiFab-default MuiFab-root MuiFab-circular MuiFab-sizeSmall MuiFab-default css-1q89r9i\" tabindex=\"0\" type=\"button\" aria-label=\"Scroll back to top\" data-ga-event-category=\"docs\" data-ga-event-action=\"click-back-to-top\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-14rkw53\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowUpRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M8.12 14.71 12 10.83l3.88 3.88c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L12.7 8.71a.9959.9959 0 0 0-1.41 0L6.7 13.3c-.39.39-.39 1.02 0 1.41.39.38 1.03.39 1.42 0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiContainer-root css-87yqrt\" id=\"main-content\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div style=\"--MuiDocs-header-height:64px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"error-icon\" viewBox=\"0 0 20 20\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path fill-rule=\"evenodd\" d=\"M2 7.4v5.2a2 2 0 0 0 .586 1.414l3.4 3.4A2 2 0 0 0 7.4 18h5.2a2 2 0 0 0 1.414-.586l3.4-3.4A2 2 0 0 0 18 12.6V7.4a2 2 0 0 0-.586-1.414l-3.4-3.4A2 2 0 0 0 12.6 2H7.4a2 2 0 0 0-1.414.586l-3.4 3.4A2 2 0 0 0 2 7.4Zm11.03-.43a.75.75 0 0 1 0 1.06L11.06 10l1.97 1.97a.75.75 0 1 1-1.06 1.06L10 11.06l-1.97 1.97a.75.75 0 0 1-1.06-1.06L8.94 10 6.97 8.03a.75.75 0 0 1 1.06-1.06L10 8.94l1.97-1.97a.75.75 0 0 1 1.06 0Z\" clip-rule=\"evenodd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"warning-icon\" viewBox=\"0 0 20 20\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M2.33 17a.735.735 0 0 1-.665-.375.631.631 0 0 1-.094-.375.898.898 0 0 1 .115-.396L9.353 3.062a.621.621 0 0 1 .281-.27.85.85 0 0 1 .729 0 .622.622 0 0 1 .281.27l7.667 12.792c.07.125.108.257.114.396a.63.63 0 0 1-.093.375.842.842 0 0 1-.271.27.728.728 0 0 1-.394.105H2.33Zm7.664-2.5c.211 0 .39-.072.536-.214a.714.714 0 0 0 .218-.532.736.736 0 0 0-.214-.535.714.714 0 0 0-.531-.22.736.736 0 0 0-.536.215.714.714 0 0 0-.219.531c0 .212.072.39.215.536.143.146.32.219.531.219Zm0-2.5c.211 0 .39-.072.536-.216a.72.72 0 0 0 .218-.534v-2.5a.728.728 0 0 0-.214-.534.72.72 0 0 0-.531-.216.734.734 0 0 0-.536.216.72.72 0 0 0-.219.534v2.5c0 .212.072.39.215.534a.72.72 0 0 0 .531.216Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"success-icon\" viewBox=\"0 0 20 20\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"m8.938 10.875-1.25-1.23a.718.718 0 0 0-.521-.228.718.718 0 0 0-.521.229.73.73 0 0 0 0 1.062l1.77 1.771c.153.153.327.23.521.23a.718.718 0 0 0 .521-.23l3.896-3.896a.73.73 0 0 0 0-1.062.718.718 0 0 0-.52-.23.718.718 0 0 0-.521.23l-3.376 3.354ZM10 18a7.796 7.796 0 0 1-3.104-.625 8.065 8.065 0 0 1-2.552-1.719 8.064 8.064 0 0 1-1.719-2.552A7.797 7.797 0 0 1 2 10c0-1.111.208-2.15.625-3.115a8.064 8.064 0 0 1 4.27-4.26A7.797 7.797 0 0 1 10 2c1.111 0 2.15.208 3.115.625a8.096 8.096 0 0 1 4.26 4.26C17.792 7.851 18 8.89 18 10a7.797 7.797 0 0 1-.625 3.104 8.066 8.066 0 0 1-4.26 4.271A7.774 7.774 0 0 1 10 18Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"info-icon\" viewBox=\"0 0 20 20\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9.996 14c.21 0 .39-.072.535-.216a.72.72 0 0 0 .219-.534v-3.5a.728.728 0 0 0-.214-.534.72.72 0 0 0-.532-.216.734.734 0 0 0-.535.216.72.72 0 0 0-.219.534v3.5c0 .213.071.39.214.534a.72.72 0 0 0 .532.216Zm0-6.5c.21 0 .39-.071.535-.214a.714.714 0 0 0 .219-.532.736.736 0 0 0-.214-.535.714.714 0 0 0-.532-.219.736.736 0 0 0-.535.214.714.714 0 0 0-.219.532c0 .21.071.39.214.535.143.146.32.219.532.219Zm.01 10.5a7.81 7.81 0 0 1-3.11-.625 8.065 8.065 0 0 1-2.552-1.719 8.066 8.066 0 0 1-1.719-2.551A7.818 7.818 0 0 1 2 9.99c0-1.104.208-2.14.625-3.105a8.066 8.066 0 0 1 4.27-4.26A7.818 7.818 0 0 1 10.009 2a7.75 7.75 0 0 1 3.106.625 8.083 8.083 0 0 1 4.26 4.265A7.77 7.77 0 0 1 18 9.994a7.81 7.81 0 0 1-.625 3.11 8.066 8.066 0 0 1-1.719 2.552 8.083 8.083 0 0 1-2.546 1.719 7.77 7.77 0 0 1-3.104.625Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"copied-icon\" viewBox=\"0 0 24 24\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.24 11.28L9.69 11.2c-.38-.39-.38-1.01 0-1.4.39-.39 1.02-.39 1.41 0l1.36 1.37 4.42-4.46c.39-.39 1.02-.39 1.41 0 .38.39.38 1.01 0 1.4l-5.13 5.17c-.37.4-1.01.4-1.4 0zM3 6c-.55 0-1 .45-1 1v13c0 1.1.9 2 2 2h13c.55 0 1-.45 1-1s-.45-1-1-1H5c-.55 0-1-.45-1-1V7c0-.55-.45-1-1-1z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"copy-icon\" viewBox=\"0 0 24 24\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M15 20H5V7c0-.55-.45-1-1-1s-1 .45-1 1v13c0 1.1.9 2 2 2h10c.55 0 1-.45 1-1s-.45-1-1-1zm5-4V4c0-1.1-.9-2-2-2H9c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h9c1.1 0 2-.9 2-2zm-2 0H9V4h9v12z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "+"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"anchor-link-icon\" viewBox=\"0 0 12 6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M8.9176 0.083252H7.1676C6.84677 0.083252 6.58427 0.345752 6.58427 0.666585C6.58427 0.987419 6.84677 1.24992 7.1676 1.24992H8.9176C9.8801 1.24992 10.6676 2.03742 10.6676 2.99992C10.6676 3.96242 9.8801 4.74992 8.9176 4.74992H7.1676C6.84677 4.74992 6.58427 5.01242 6.58427 5.33325C6.58427 5.65409 6.84677 5.91659 7.1676 5.91659H8.9176C10.5276 5.91659 11.8343 4.60992 11.8343 2.99992C11.8343 1.38992 10.5276 0.083252 8.9176 0.083252ZM3.6676 2.99992C3.6676 3.32075 3.9301 3.58325 4.25094 3.58325H7.75094C8.07177 3.58325 8.33427 3.32075 8.33427 2.99992C8.33427 2.67909 8.07177 2.41659 7.75094 2.41659H4.25094C3.9301 2.41659 3.6676 2.67909 3.6676 2.99992ZM4.83427 4.74992H3.08427C2.12177 4.74992 1.33427 3.96242 1.33427 2.99992C1.33427 2.03742 2.12177 1.24992 3.08427 1.24992H4.83427C5.1551 1.24992 5.4176 0.987419 5.4176 0.666585C5.4176 0.345752 5.1551 0.083252 4.83427 0.083252H3.08427C1.47427 0.083252 0.167603 1.38992 0.167603 2.99992C0.167603 4.60992 1.47427 5.91659 3.08427 5.91659H4.83427C5.1551 5.91659 5.4176 5.65409 5.4176 5.33325C5.4176 5.01242 5.1551 4.74992 4.83427 4.74992Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg style=\"display: none;\" xmlns=\"http://www.w3.org/2000/svg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<symbol id=\"comment-link-icon\" viewBox=\"0 0 24 24\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M22.8481 4C22.8481 2.9 21.9481 2 20.8481 2H4.84814C3.74814 2 2.84814 2.9 2.84814 4V16C2.84814 17.1 3.74814 18 4.84814 18H18.8481L22.8481 22V4ZM16.8481 11H13.8481V14C13.8481 14.55 13.3981 15 12.8481 15C12.2981 15 11.8481 14.55 11.8481 14V11H8.84814C8.29814 11 7.84814 10.55 7.84814 10C7.84814 9.45 8.29814 9 8.84814 9H11.8481V6C11.8481 5.45 12.2981 5 12.8481 5C13.3981 5 13.8481 5.45 13.8481 6V9H16.8481C17.3981 9 17.8481 9.45 17.8481 10C17.8481 10.55 17.3981 11 16.8481 11Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h1>Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"description\">Buttons let users take actions and make choices with a single tap."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"css-1tor9s0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiChip-root MuiChip-outlined MuiChip-sizeSmall MuiChip-colorDefault MuiChip-clickable MuiChip-clickableColorDefault MuiChip-outlinedDefault css-7pgmj0\" tabindex=\"0\" rel=\"nofollow\" href=\"https://github.com/mui/material-ui/labels/component%3A%20button\" data-ga-event-category=\"ComponentLinkHeader\" data-ga-event-action=\"click\" data-ga-event-label=\"Feedback\" data-ga-event-split=\"0.1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-colorPrimary MuiSvgIcon-fontSizeMedium MuiChip-icon MuiChip-iconSmall MuiChip-iconColorPrimary css-omqz4j\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ChatRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2M7 9h10c.55 0 1 .45 1 1s-.45 1-1 1H7c-.55 0-1-.45-1-1s.45-1 1-1m6 5H7c-.55 0-1-.45-1-1s.45-1 1-1h6c.55 0 1 .45 1 1s-.45 1-1 1m4-6H7c-.55 0-1-.45-1-1s.45-1 1-1h10c.55 0 1 .45 1 1s-.45 1-1 1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSmall css-cxrmjv\">Feedback"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiChip-root MuiChip-outlined MuiChip-sizeSmall MuiChip-colorDefault MuiChip-clickable MuiChip-clickableColorDefault MuiChip-outlinedDefault css-7pgmj0\" tabindex=\"0\" rel=\"nofollow\" href=\"https://bundlephobia.com/package/@mui/joy@latest\" data-ga-event-category=\"ComponentLinkHeader\" data-ga-event-action=\"click\" data-ga-event-label=\"Bundle size\" data-ga-event-split=\"0.1\" title=\"Scroll down to 'Exports Analysis' for a more detailed report.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-colorPrimary MuiSvgIcon-fontSizeMedium MuiChip-icon MuiChip-iconSmall MuiChip-iconColorPrimary css-omqz4j\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"BundleSizeIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<g fill=\"currentColor\" fill-rule=\"nonzero\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M5.84 3c-.52 0-1 .25-1.3.67l-1.4 2.05c-.06.09-.1.19-.14.28h8V3H5.84zM20.86 5.72l-1.4-2.05c-.3-.42-.81-.67-1.33-.67H13v3h8c-.05-.1-.08-.2-.14-.28z\" fill-opacity=\".79\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M20.98 7H3.02L3 7.11V19.4c0 .89.71 1.61 1.58 1.61h14.84A1.6 1.6 0 0021 19.4V7.1L20.98 7zm-6.87 5.36H9.89a1.6 1.6 0 01-1.58-1.61c0-.89.7-1.6 1.58-1.6h4.22c.87 0 1.58.71 1.58 1.6 0 .89-.7 1.6-1.58 1.6z\" fill-opacity=\".87\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSmall css-cxrmjv\">Bundle size"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiChip-root MuiChip-outlined MuiChip-sizeSmall MuiChip-colorDefault MuiChip-clickable MuiChip-clickableColorDefault MuiChip-outlinedDefault css-7pgmj0\" tabindex=\"0\" rel=\"nofollow\" href=\"https://www.w3.org/WAI/ARIA/apg/patterns/button/\" data-ga-event-category=\"ComponentLinkHeader\" data-ga-event-action=\"click\" data-ga-event-label=\"WAI-ARIA\" data-ga-event-split=\"0.1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-colorPrimary MuiSvgIcon-fontSizeMedium MuiChip-icon MuiChip-iconSmall MuiChip-iconColorPrimary css-omqz4j\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"W3CIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<g fill-rule=\"nonzero\" fill=\"none\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M6.92 6.1l2.33 7.99 2.32-8h6.3v.8l-2.37 4.14c.83.27 1.46.76 1.89 1.47.43.71.64 1.55.64 2.51 0 1.2-.31 2.2-.94 3a2.93 2.93 0 01-2.42 1.22 2.9 2.9 0 01-1.96-.72 4.25 4.25 0 01-1.23-1.96l1.31-.55c.2.5.45.9.76 1.18.32.28.69.43 1.12.43.44 0 .82-.26 1.13-.76.31-.51.47-1.12.47-1.84 0-.79-.17-1.4-.5-1.83-.38-.5-.99-.76-1.81-.76h-.64v-.78l2.24-3.92h-2.7l-.16.26-3.3 11.25h-.15l-2.4-8.14-2.41 8.14h-.16L.43 6.1H2.1l2.33 7.99L6 8.71 5.24 6.1h1.68z\" fill=\"#005A9C\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<g fill=\"currentColor\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M23.52 6.25l.28 1.62-.98 1.8s-.38-.76-1.01-1.19c-.53-.35-.87-.43-1.41-.33-.7.14-1.48.93-1.82 1.9-.41 1.18-.42 1.74-.43 2.26a4.9 4.9 0 00.11 1.33s-.6-1.06-.59-2.61c0-1.1.19-2.11.72-3.1.47-.87 1.17-1.4 1.8-1.45.63-.07 1.14.23 1.53.55.42.33.83 1.07.83 1.07l.97-1.85zM23.64 15.4s-.43.75-.7 1.04c-.27.28-.76.79-1.36 1.04-.6.25-.91.3-1.5.25a3.03 3.03 0 01-1.34-.52 5.08 5.08 0 01-1.67-2.04s.24.75.39 1.07c.09.18.36.74.74 1.23a3.5 3.5 0 002.1 1.42c1.04.18 1.76-.27 1.94-.38a5.32 5.32 0 001.4-1.43c.1-.14.25-.43.25-.43l-.25-1.25z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSmall css-cxrmjv\">WAI-ARIA"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiChip-root MuiChip-outlined MuiChip-sizeSmall MuiChip-colorDefault MuiChip-clickable MuiChip-clickableColorDefault MuiChip-outlinedDefault css-1yq2i8q\" tabindex=\"0\" rel=\"nofollow\" href=\"https://mui.com/store/items/figma-react/?utm_source=docs&amp;utm_medium=referral&amp;utm_campaign=component-link-header\" data-ga-event-category=\"ComponentLinkHeader\" data-ga-event-action=\"click\" data-ga-event-label=\"Figma\" data-ga-event-split=\"0.1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiChip-icon MuiChip-iconSmall MuiChip-iconColorDefault css-vubbuv\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FigmaIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<g fill-rule=\"nonzero\" fill=\"none\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M8 24a4 4 0 004-4v-4H8a4 4 0 000 8z\" fill=\"#0ACF83\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M4 12a4 4 0 014-4h4v8H8a4 4 0 01-4-4z\" fill=\"#A259FF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M4 4a4 4 0 014-4h4v8H8a4 4 0 01-4-4z\" fill=\"#F24E1E\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 0h4a4 4 0 010 8h-4V0z\" fill=\"#FF7262\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M20 12a4 4 0 11-8 0 4 4 0 018 0z\" fill=\"#1ABCFE\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSmall css-cxrmjv\">Figma"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"introduction\">Introduction<a aria-labelledby=\"introduction\" class=\"anchor-link\" href=\"#introduction\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"introduction\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Buttons communicate actions that users can take."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "The Joy UI Button component replaces the native HTML <code>&lt;button&gt; element and offers expanded options for styling and accessibility."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonUsage\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:R659l6kud6:\" class=\"css-1tqnzfd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1n780lk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13yh57n\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1dl3sot\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-10egq61\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Hello world"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantSolid MuiIconButton-colorPrimary MuiIconButton-sizeMd css-1jg155g\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-nd3o6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-jsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">onClick<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token punctuation\">(<span class=\"token punctuation\">) <span class=\"token operator\">=&gt; <span class=\"token punctuation\">{<span class=\"token punctuation\">}<span class=\"token punctuation\">} <span class=\"token punctuation\">/&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSheet-root MuiSheet-variantPlain MuiSheet-colorNeutral css-lkarvp\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-3pku2n\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"usage-props\" class=\"MuiTypography-root MuiTypography-body-md css-cuuo2i\">Playground"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button aria-label=\"Reset all\" class=\"MuiIconButton-root MuiIconButton-variantOutlined MuiIconButton-colorPrimary MuiIconButton-sizeSm css-xz2pcu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ReplayRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 5V2.21c0-.45-.54-.67-.85-.35l-3.8 3.79c-.2.2-.2.51 0 .71l3.79 3.79c.32.31.86.09.86-.36V7c3.73 0 6.68 3.42 5.86 7.29-.47 2.27-2.31 4.1-4.57 4.57-3.57.75-6.75-1.7-7.23-5.01-.07-.48-.49-.85-.98-.85-.6 0-1.08.53-1 1.13.62 4.39 4.8 7.64 9.53 6.72 3.12-.61 5.63-3.12 6.24-6.24C20.84 9.48 16.94 5 12 5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-horizontal css-zwz8tn\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1ydeszw\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeSm css-y51nzi\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":Rrlal659l6kud6:\" id=\":Rrlal659l6kud6:-label\" class=\"MuiFormLabel-root css-942wyr\">variant"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div role=\"radiogroup\" id=\":Rrlal659l6kud6:\" aria-labelledby=\":Rrlal659l6kud6:-label\" class=\"MuiRadioGroup-root MuiRadioGroup-horizontal MuiRadioGroup-variantPlain MuiRadioGroup-colorNeutral MuiRadioGroup-sizeSm css-1d6vppb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-first-child=\"\" data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorNeutral MuiChip-sizeSm MuiChip-variantPlain css-120t5sa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R1mkrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-1nsjysk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-z2phl0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-msgya0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R159mkrlal659l6kud6:\" name=\"Button-variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"plain\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R159mkrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorNeutral MuiChip-sizeSm MuiChip-variantPlain css-120t5sa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R2mkrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-1nsjysk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-z2phl0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-msgya0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R15amkrlal659l6kud6:\" name=\"Button-variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"outlined\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R15amkrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorNeutral MuiChip-sizeSm MuiChip-variantPlain css-120t5sa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R3mkrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-1nsjysk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-z2phl0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-msgya0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R15bmkrlal659l6kud6:\" name=\"Button-variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"soft\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R15bmkrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-last-child=\"\" data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorPrimary MuiChip-sizeSm MuiChip-variantPlain css-1gl340x\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R4mkrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root Mui-checked MuiRadio-variantSolid MuiRadio-colorPrimary MuiRadio-sizeSm css-1idhp3u\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio Mui-checked css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action Mui-checked css-3pgois\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R15cmkrlal659l6kud6:\" name=\"Button-variant\" class=\"MuiRadio-input css-zo1pqd\" checked=\"\" value=\"solid\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R15cmkrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeSm css-iapz91\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1blal659l6kud6:\" id=\":R1blal659l6kud6:-label\" class=\"MuiFormLabel-root css-942wyr\">color"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div role=\"radiogroup\" id=\":R1blal659l6kud6:\" aria-labelledby=\":R1blal659l6kud6:-label\" class=\"MuiRadioGroup-root MuiRadioGroup-horizontal MuiRadioGroup-variantPlain MuiRadioGroup-colorNeutral MuiRadioGroup-sizeSm css-1mtwn1e\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-first-child=\"\" data-parent=\"RadioGroup\" class=\"MuiSheet-root MuiSheet-variantSolid MuiSheet-colorPrimary css-1hjfsyo\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root Mui-checked MuiRadio-variantSolid MuiRadio-colorPrimary MuiRadio-sizeSm css-1ppsglh\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio Mui-checked css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action Mui-checked css-3pgois\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1hmlblal659l6kud6:\" name=\"Button-color\" class=\"MuiRadio-input css-zo1pqd\" checked=\"\" value=\"primary\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1hmlblal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">primary"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMd css-1izm3r7\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"CheckIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiSheet-root MuiSheet-variantSolid MuiSheet-colorNeutral css-1843l61\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantSolid MuiRadio-colorNeutral MuiRadio-sizeSm css-g1zs88\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-11o746a\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1imlblal659l6kud6:\" name=\"Button-color\" class=\"MuiRadio-input css-zo1pqd\" value=\"neutral\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1imlblal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">neutral"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiSheet-root MuiSheet-variantSolid MuiSheet-colorDanger css-bhgqnr\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantSolid MuiRadio-colorDanger MuiRadio-sizeSm css-18yq4mg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-1p9bq1n\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1jmlblal659l6kud6:\" name=\"Button-color\" class=\"MuiRadio-input css-zo1pqd\" value=\"danger\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1jmlblal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">danger"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiSheet-root MuiSheet-variantSolid MuiSheet-colorSuccess css-1vbxr3q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantSolid MuiRadio-colorSuccess MuiRadio-sizeSm css-16qiwfm\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-16koa46\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1kmlblal659l6kud6:\" name=\"Button-color\" class=\"MuiRadio-input css-zo1pqd\" value=\"success\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1kmlblal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">success"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-last-child=\"\" data-parent=\"RadioGroup\" class=\"MuiSheet-root MuiSheet-variantSolid MuiSheet-colorWarning css-1cslv8\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantSolid MuiRadio-colorWarning MuiRadio-sizeSm css-10lxwlz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-eetb3f\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1lmlblal659l6kud6:\" name=\"Button-color\" class=\"MuiRadio-input css-zo1pqd\" value=\"warning\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1lmlblal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">warning"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeSm css-y51nzi\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1rlal659l6kud6:\" id=\":R1rlal659l6kud6:-label\" class=\"MuiFormLabel-root css-942wyr\">size"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div role=\"radiogroup\" id=\":R1rlal659l6kud6:\" aria-labelledby=\":R1rlal659l6kud6:-label\" class=\"MuiRadioGroup-root MuiRadioGroup-horizontal MuiRadioGroup-variantPlain MuiRadioGroup-colorNeutral MuiRadioGroup-sizeSm css-1d6vppb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-first-child=\"\" data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorNeutral MuiChip-sizeSm MuiChip-variantPlain css-120t5sa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R1mlrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-1nsjysk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-z2phl0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-msgya0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":Rilmlrlal659l6kud6:\" name=\"Button-size\" class=\"MuiRadio-input css-zo1pqd\" value=\"sm\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":Rilmlrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">sm"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorPrimary MuiChip-sizeSm MuiChip-variantPlain css-1gl340x\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R2mlrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root Mui-checked MuiRadio-variantSolid MuiRadio-colorPrimary MuiRadio-sizeSm css-1idhp3u\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio Mui-checked css-125e86y\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action Mui-checked css-3pgois\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":Rimmlrlal659l6kud6:\" name=\"Button-size\" class=\"MuiRadio-input css-zo1pqd\" checked=\"\" value=\"md\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":Rimmlrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">md"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div data-last-child=\"\" data-parent=\"RadioGroup\" class=\"MuiChip-root MuiChip-colorNeutral MuiChip-sizeSm MuiChip-variantPlain css-120t5sa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiChip-label MuiChip-labelSm css-tymi7a\" id=\":R3mlrlal659l6kud6:\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-1nsjysk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-z2phl0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-msgya0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":Rinmlrlal659l6kud6:\" name=\"Button-size\" class=\"MuiRadio-input css-zo1pqd\" value=\"lg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":Rinmlrlal659l6kud6:\" class=\"MuiRadio-label css-1vyzt37\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-inherit css-hke6pf\">lg"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeSm css-1mty81q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R2blal659l6kud6:\" id=\":R2blal659l6kud6:-label\" class=\"MuiFormLabel-root css-10s36vm\">disabled"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSwitch-root MuiSwitch-variantSolid MuiSwitch-colorNeutral MuiSwitch-sizeSm css-cljtrf\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiSwitch-track css-d1fwab\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiSwitch-thumb css-16zegtk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSwitch-action css-u74y05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"checkbox\" id=\":R2blal659l6kud6:\" class=\"MuiSwitch-input css-q7japm\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"basics\">Basics<a aria-labelledby=\"basics\" class=\"anchor-link\" href=\"#basics\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"basics\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-jsx\"><span class=\"token keyword\">import Button <span class=\"token keyword\">from <span class=\"token string\">'@mui/joy/Button'<span class=\"token punctuation\">;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button data-ga-event-category=\"code\" data-ga-event-action=\"copy-click\" aria-label=\"Copy the code\" class=\"MuiCode-copy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copy-icon\" xlink:href=\"#copy-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#copied-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiCode-copyKeypress\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>(or $keyC<span>)"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The Joy UI Button behaves similarly to the native HTML <code>&lt;button&gt;, so it wraps around the text displayed on its surface."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The demo below shows the three basic states available to the Button: default, disabled, and loading."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"BasicButtons\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:R759l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13rcduy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">Disabled"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-4qk412\">Loading<span class=\"MuiButton-loadingIndicatorCenter css-1xdipbz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-BasicButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-BasicButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-BasicButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-BasicButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-BasicButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-BasicButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"BasicButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"BasicButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:R759l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;Button<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">disabled<span class=\"token punctuation\">&gt;Disabled<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading<span class=\"token punctuation\">&gt;Loading<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button&gt;Button&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button disabled&gt;Disabled&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading&gt;Loading&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"disabled\">Disabled<a aria-labelledby=\"disabled\" class=\"anchor-link\" href=\"#disabled\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"disabled\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Use the <code>disabled prop to disable interaction and focus:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonDisabled\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:R859l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13rcduy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"AddIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSoft MuiButton-colorNeutral MuiButton-sizeMd css-fknhaw\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"AddIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantOutlined MuiButton-colorSuccess MuiButton-sizeMd css-1ejw0u5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"AddIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantPlain MuiButton-colorDanger MuiButton-sizeMd css-1nm01pu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"AddIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonDisabled.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonDisabled.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonDisabled.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonDisabled.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonDisabled.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonDisabled.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonDisabled.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonDisabled.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:R859l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">disabled <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"solid<span class=\"token punctuation\">\" <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Add <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">disabled <span class=\"token attr-name\">color<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"neutral<span class=\"token punctuation\">\" <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"soft<span class=\"token punctuation\">\" <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Add <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">disabled <span class=\"token attr-name\">color<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"success<span class=\"token punctuation\">\" <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"outlined<span class=\"token punctuation\">\" <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Add <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">disabled <span class=\"token attr-name\">color<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"danger<span class=\"token punctuation\">\" <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"plain<span class=\"token punctuation\">\" <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Add <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button disabled variant=\"solid\" startDecorator={&lt;Add /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button disabled color=\"neutral\" variant=\"soft\" startDecorator={&lt;Add /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button disabled color=\"success\" variant=\"outlined\" startDecorator={&lt;Add /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button disabled color=\"danger\" variant=\"plain\" startDecorator={&lt;Add /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"loading\">Loading<a aria-labelledby=\"loading\" class=\"anchor-link\" href=\"#loading\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"loading\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Add the <code>loading prop to show the Button's loading state."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "The Button is <a href=\"#disabled\">disabled as long as it's loading."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "See <a href=\"#loading-indicator\">Loading indicator and <a href=\"#loading-position\">Loading position for customization options."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoading\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:R959l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13rcduy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-4qk412\">Solid<span class=\"MuiButton-loadingIndicatorCenter css-1xdipbz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSoft MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-1u7d4x1\">Soft<span class=\"MuiButton-loadingIndicatorCenter css-u14a91\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantOutlined MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-115efzs\">Outlined<span class=\"MuiButton-loadingIndicatorCenter css-pewfll\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantPlain MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-17k7gh\">Plain<span class=\"MuiButton-loadingIndicatorCenter css-183hfhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoading.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoading.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoading.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoading.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoading.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoading.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoading.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoading.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:R959l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"solid<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"soft<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"outlined<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"plain<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button loading variant=\"solid\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading variant=\"soft\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading variant=\"outlined\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading variant=\"plain\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"customization\">Customization<a aria-labelledby=\"customization\" class=\"anchor-link\" href=\"#customization\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"customization\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"variants\">Variants<a aria-labelledby=\"variants\" class=\"anchor-link\" href=\"#variants\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"variants\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The Button component supports Joy UI's four <a href=\"/joy-ui/main-features/global-variants/\">global variants: <code>solid (default), <code>soft, <code>outlined, and <code>plain."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonVariants\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Ra59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13rcduy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSoft MuiButton-colorPrimary MuiButton-sizeMd css-1u7d4x1\">Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantOutlined MuiButton-colorPrimary MuiButton-sizeMd css-115efzs\">Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantPlain MuiButton-colorPrimary MuiButton-sizeMd css-17k7gh\">Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonVariants.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonVariants.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonVariants.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonVariants.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonVariants.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonVariants.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonVariants.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonVariants.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Ra59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"solid<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Solid<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"soft<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Soft<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"outlined<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Outlined<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">variant<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"plain<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Plain<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button variant=\"solid\"&gt;Solid&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button variant=\"soft\"&gt;Soft&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button variant=\"outlined\"&gt;Outlined&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button variant=\"plain\"&gt;Plain&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<aside class=\"MuiCallout-root MuiCallout-info\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#info-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCallout-content\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>To learn how to add your own variants, check out <a href=\"/joy-ui/customization/themed-components/#extend-variants\">Themed components—Extend variants."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Note that you lose the global variants when you add custom variants."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"sizes\">Sizes<a aria-labelledby=\"sizes\" class=\"anchor-link\" href=\"#sizes\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"sizes\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The Button component comes in three sizes: <code>sm, <code>md (default), and <code>lg."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonSizes\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rb59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-mjha5m\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeSm css-18lygt3\">Small"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">Medium"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeLg css-1euqozh\">Large"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonSizes.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonSizes.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonSizes.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonSizes.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonSizes.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonSizes.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonSizes.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonSizes.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Rb59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">size<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"sm<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Small<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">size<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"md<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Medium<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">size<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"lg<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;Large<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button size=\"sm\"&gt;Small&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button size=\"md\"&gt;Medium&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button size=\"lg\"&gt;Large&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<aside class=\"MuiCallout-root MuiCallout-info\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#info-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCallout-content\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>To learn how to add custom sizes to the component, check out <a href=\"/joy-ui/customization/themed-components/#extend-sizes\">Themed components—Extend sizes."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"colors\">Colors<a aria-labelledby=\"colors\" class=\"anchor-link\" href=\"#colors\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"colors\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Every palette included in the theme is available via the <code>color prop."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Play around combining different colors with different variants."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonColors\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rc59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-k5rr6j\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-t2l4g\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">Primary"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorNeutral MuiButton-sizeMd css-1mk4o9b\">Neutral"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorDanger MuiButton-sizeMd css-1pfx2sq\">Danger"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorSuccess MuiButton-sizeMd css-5ob2ia\">Success"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorWarning MuiButton-sizeMd css-z846g6\">Warning"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSheet-root MuiSheet-variantPlain MuiSheet-colorNeutral css-o1fmta\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p id=\"variant-label\" class=\"MuiTypography-root MuiTypography-body-sm css-rxbkv3\">Variant:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div role=\"radiogroup\" aria-labelledby=\"variant-label\" class=\"MuiRadioGroup-root MuiRadioGroup-vertical MuiRadioGroup-variantPlain MuiRadioGroup-colorNeutral MuiRadioGroup-sizeSm css-7zjktf\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span data-first-child=\"\" data-parent=\"RadioGroup\" class=\"MuiRadio-root Mui-checked MuiRadio-variantOutlined MuiRadio-colorPrimary MuiRadio-sizeSm css-na8m2q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio Mui-checked css-n18l0f\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-icon css-jm3ztl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action Mui-checked css-tpe6zg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R1mlalc59l6kud6:\" name=\"variant\" class=\"MuiRadio-input css-zo1pqd\" checked=\"\" value=\"solid\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R1mlalc59l6kud6:\" class=\"MuiRadio-label css-1fjtzvx\">Solid"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span data-parent=\"RadioGroup\" class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-mugu6v\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-ti0yxa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-icon css-7aolzd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-tpe6zg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R2mlalc59l6kud6:\" name=\"variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"soft\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R2mlalc59l6kud6:\" class=\"MuiRadio-label css-1fjtzvx\">Soft"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span data-parent=\"RadioGroup\" class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-mugu6v\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-ti0yxa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-icon css-7aolzd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-tpe6zg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R3mlalc59l6kud6:\" name=\"variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"outlined\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R3mlalc59l6kud6:\" class=\"MuiRadio-label css-1fjtzvx\">Outlined"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span data-last-child=\"\" data-parent=\"RadioGroup\" class=\"MuiRadio-root MuiRadio-variantOutlined MuiRadio-colorNeutral MuiRadio-sizeSm css-mugu6v\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-radio css-ti0yxa\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-icon css-7aolzd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiRadio-action css-tpe6zg\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"radio\" id=\":R4mlalc59l6kud6:\" name=\"variant\" class=\"MuiRadio-input css-zo1pqd\" value=\"plain\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R4mlalc59l6kud6:\" class=\"MuiRadio-label css-1fjtzvx\">Plain"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonColors.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonColors.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonColors.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonColors.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonColors.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonColors.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonColors.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonColors.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-18a6laq\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"decorators\">Decorators<a aria-labelledby=\"decorators\" class=\"anchor-link\" href=\"#decorators\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"decorators\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Use the <code>startDecorator and <code>endDecorator props to append actions and icons to either side of the Button:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonIcons\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rd59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-13rcduy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"AddIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Add to cart"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorSuccess MuiButton-sizeMd css-5ob2ia\">Go to checkout<span class=\"MuiButton-endDecorator css-1hd3m4q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"KeyboardArrowRightIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonIcons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonIcons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonIcons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonIcons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonIcons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonIcons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonIcons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonIcons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Rd59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Add <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;Add to cart<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">endDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">KeyboardArrowRight <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">} <span class=\"token attr-name\">color<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"success<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Go to checkout"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button startDecorator={&lt;Add /&gt;}&gt;Add to cart&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button endDecorator={&lt;KeyboardArrowRight /&gt;} color=\"success\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Go to checkout"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"loading-indicator\">Loading indicator<a aria-labelledby=\"loading-indicator\" class=\"anchor-link\" href=\"#loading-indicator\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"loading-indicator\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The default loading indicator uses the <a href=\"/joy-ui/react-circular-progress/\">Circular Progress component."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Use the <code>loadingIndicator prop to replace it with a custom indicator, as shown below:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingIndicator\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Re59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-jj2ztu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-4qk412\">Default<span class=\"MuiButton-loadingIndicatorCenter css-1xdipbz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-4qk412\">Custom<span class=\"MuiButton-loadingIndicatorCenter css-1xdipbz\">Loading…"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoadingIndicator.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoadingIndicator.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoadingIndicator.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoadingIndicator.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoadingIndicator.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoadingIndicator.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingIndicator.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingIndicator.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Re59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading<span class=\"token punctuation\">&gt;Default<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">loadingIndicator<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"Loading…<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Custom"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button loading&gt;Default&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading loadingIndicator=\"Loading…\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Custom"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"loading-position\">Loading position<a aria-labelledby=\"loading-position\" class=\"anchor-link\" href=\"#loading-position\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"loading-position\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The <code>loadingPosition prop sets the position of the Button's loading indicator."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "It supports three values:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>center (default): The loading indicator is nested inside the <code>loadingIndicatorCenter slot and replaces the Button's contents when in the loading state."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>start: The loading indicator replaces the <a href=\"#decorators\">starting decorator when the Button is in the loading state."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>end: The loading indicator replaces the <a href=\"#decorators\">ending decorator when the Button is in the loading state."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingPosition\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rf59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-jj2ztu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-ub0hy2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Start"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root Mui-disabled MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd MuiButton-loading css-ub0hy2\">End<span class=\"MuiButton-endDecorator css-1hd3m4q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span role=\"progressbar\" style=\"--CircularProgress-percent:25\" class=\"MuiCircularProgress-root MuiCircularProgress-colorPrimary MuiCircularProgress-variantSoft MuiCircularProgress-sizeMd css-zdmweu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiCircularProgress-svg css-18a5s3t\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-track css-1c73xhe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle class=\"MuiCircularProgress-progress css-skc48w\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoadingPosition.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLoadingPosition.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoadingPosition.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLoadingPosition.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoadingPosition.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLoadingPosition.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingPosition.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLoadingPosition.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Rf59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">loadingPosition<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"start<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Start"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">loading <span class=\"token attr-name\">loadingPosition<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"end<span class=\"token punctuation\">\" <span class=\"token attr-name\">endDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">SendIcon <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "End"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button loading loadingPosition=\"start\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Start"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;Button loading loadingPosition=\"end\" endDecorator={&lt;SendIcon /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "End"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"link-button\">Link Button<a aria-labelledby=\"link-button\" class=\"anchor-link\" href=\"#link-button\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"link-button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Buttons let users take actions, but if that action is to navigate to a new page, then an anchor tag is generally preferable over a button tag."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>If you need the style of a button with the functionality of a link, then you can use the <code>component prop to replace the default <code>&lt;button&gt; with an <code>&lt;a&gt;, as shown below:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLink\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rg59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-huskxe\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a href=\"#as-link\" class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"OpenInNewIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Open in new tab"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a aria-label=\"Open in new tab\" href=\"#as-link\" class=\"MuiIconButton-root MuiIconButton-variantPlain MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1vgb0z0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"OpenInNewIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLink.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-ButtonLink.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLink.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-ButtonLink.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLink.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-ButtonLink.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLink.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonLink.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-9xb0dz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-root MuiCollapse-vertical MuiCollapse-entered css-c4sutr\" style=\"min-height:0px\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapper MuiCollapse-vertical css-hboir5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCollapse-wrapperInner MuiCollapse-vertical css-8atqhb\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-1fh90ke\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"scrollContainer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demoSource-:Rg59l6kud6H1:\" class=\"css-8u7p7s\" style=\"position:relative;text-align:left;box-sizing:border-box;padding:0;overflow:hidden\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre aria-hidden=\"true\" style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:relative;pointer-events:none;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\"><code class=\"language-tsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button <span class=\"token attr-name\">component<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"a<span class=\"token punctuation\">\" <span class=\"token attr-name\">href<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"#as-link<span class=\"token punctuation\">\" <span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">OpenInNew <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Open <span class=\"token keyword\">in <span class=\"token keyword\">new <span class=\"token class-name\">tab"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">Button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">IconButton <span class=\"token attr-name\">aria-label<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"Open in new tab<span class=\"token punctuation\">\" <span class=\"token attr-name\">component<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"a<span class=\"token punctuation\">\" <span class=\"token attr-name\">href<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"#as-link<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">OpenInNew <span class=\"token punctuation\">/&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">IconButton<span class=\"token punctuation\">&gt;<br>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<textarea style=\"margin:0;border:0;background:none;box-sizing:inherit;display:inherit;font-family:inherit;font-size:inherit;font-style:inherit;font-variant-ligatures:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;tab-size:inherit;text-indent:inherit;text-rendering:inherit;text-transform:inherit;white-space:pre-wrap;word-break:keep-all;overflow-wrap:break-word;position:absolute;top:0;left:0;height:100%;width:100%;resize:none;color:inherit;overflow:hidden;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;-webkit-text-fill-color:transparent;padding-top:16px;padding-right:16px;padding-bottom:16px;padding-left:16px\" class=\"npm__react-simple-code-editor__textarea\" autocapitalize=\"off\" autocomplete=\"off\" autocorrect=\"off\" spellcheck=\"false\" data-gramm=\"false\">&lt;Button component=\"a\" href=\"#as-link\" startDecorator={&lt;OpenInNew /&gt;}&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Open in new tab"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/Button&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;IconButton aria-label=\"Open in new tab\" component=\"a\" href=\"#as-link\"&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;OpenInNew /&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "&lt;/IconButton&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1oo4qtk\" aria-live=\"polite\" tabindex=\"0\">Press <kbd>Enter to start editing"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"file-upload\">File upload<a aria-labelledby=\"file-upload\" class=\"anchor-link\" href=\"#file-upload\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"file-upload\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>To create a file upload button, turn the button into a label using <code>component=\"label\" and then create a visually-hidden input with type <code>file."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"InputFileUpload\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rh59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label tabindex=\"-1\" class=\"MuiButton-root MuiButton-variantOutlined MuiButton-colorNeutral MuiButton-sizeMd css-fn0wdn\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke-width=\"1.5\" stroke=\"currentColor\" class=\"MuiSvgIcon-root MuiSvgIcon-sizeMd css-13gklk0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path stroke-linecap=\"round\" stroke-linejoin=\"round\" d=\"M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Upload a file"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"file\" class=\"css-8lbnqw\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-InputFileUpload.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-InputFileUpload.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-InputFileUpload.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-InputFileUpload.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-InputFileUpload.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-InputFileUpload.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"InputFileUpload.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"InputFileUpload.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-18a6laq\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"icon-button\">Icon Button<a aria-labelledby=\"icon-button\" class=\"anchor-link\" href=\"#icon-button\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"icon-button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-jsx\"><span class=\"token keyword\">import IconButton <span class=\"token keyword\">from <span class=\"token string\">'@mui/joy/IconButton'<span class=\"token punctuation\">;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button data-ga-event-category=\"code\" data-ga-event-action=\"copy-click\" aria-label=\"Copy the code\" class=\"MuiCode-copy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copy-icon\" xlink:href=\"#copy-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#copied-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiCode-copyKeypress\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>(or $keyC<span>)"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Use the Icon Button component for a square button to house an icon with no text content."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"IconButtons\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Ri59l6kud6:\" class=\"css-vy0fhj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-15zecap\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-horizontal MuiFormControl-sizeMd css-e8jtuj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R3ali59l6kud6:\" id=\":R3ali59l6kud6:-label\" class=\"MuiFormLabel-root css-11hmm2q\">Disabled"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSwitch-root MuiSwitch-variantSolid MuiSwitch-colorNeutral MuiSwitch-sizeMd css-1x6cp7p\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiSwitch-track css-1fyzsoi\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiSwitch-thumb css-16zegtk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSwitch-action css-u74y05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input type=\"checkbox\" id=\":R3ali59l6kud6:\" class=\"MuiSwitch-input css-q7japm\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1cnkrjn\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantSolid MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1tcv6pm\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantSoft MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1kfujnq\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantOutlined MuiIconButton-colorNeutral MuiIconButton-sizeMd css-ybycnz\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantPlain MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1vgb0z0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-IconButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"tailwind-IconButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-IconButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"css-IconButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-IconButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"system-IconButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"IconButtons.js\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"IconButtons.tsx\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-18a6laq\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-u1jr60\" aria-busy=\"true\" aria-label=\"demo source\" role=\"toolbar\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"css-variables-playground\">CSS variables playground<a aria-labelledby=\"css-variables-playground\" class=\"anchor-link\" href=\"#css-variables-playground\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"css-variables-playground\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>Play around with the CSS variables available to the Button and Icon Button components to see how the design changes."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "You can use these to customize the components with both the <code>sx prop and the theme."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"button\">Button<a aria-labelledby=\"button\" class=\"anchor-link\" href=\"#button\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"ButtonVariables\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rj59l6kud6:\" class=\"css-1tqnzfd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1n780lk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-876u7n\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1dl3sot\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButton-root MuiButton-variantSolid MuiButton-colorPrimary MuiButton-sizeMd css-4qk412\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startDecorator css-zcktug\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Favorite"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-nd3o6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-jsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token attr-name\">startDecorator<span class=\"token script language-javascript\"><span class=\"token script-punctuation punctuation\">=<span class=\"token punctuation\">{<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">FavoriteBorder <span class=\"token punctuation\">/&gt;<span class=\"token punctuation\">}"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSheet-root MuiSheet-variantPlain MuiSheet-colorNeutral css-lkarvp\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiList-root MuiList-vertical MuiList-variantPlain MuiList-colorNeutral MuiList-sizeMd css-13nh845\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-17k7nvu\" data-first-child=\"\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body-md css-1ohfyur\">CSS variables"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button aria-label=\"Reset all\" class=\"MuiIconButton-root MuiIconButton-variantOutlined MuiIconButton-colorPrimary MuiIconButton-sizeSm css-xz2pcu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ReplayRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 5V2.21c0-.45-.54-.67-.85-.35l-3.8 3.79c-.2.2-.2.51 0 .71l3.79 3.79c.32.31.86.09.86-.36V7c3.73 0 6.68 3.42 5.86 7.29-.47 2.27-2.31 4.1-4.57 4.57-3.57.75-6.75-1.7-7.23-5.01-.07-.48-.49-.85-.98-.85-.6 0-1.08.53-1 1.13.62 4.39 4.8 7.64 9.53 6.72 3.12-.61 5.63-3.12 6.24-6.24C20.84 9.48 16.94 5 12 5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-horizontal css-zwz8tn\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-cyk6x5\" data-last-child=\"\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeMd css-1h5ao69\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R3elalj59l6kud6:\" id=\":R3elalj59l6kud6:-label\" class=\"MuiFormLabel-root css-8pv1g3\">--Button-gap"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiInput-root MuiInput-variantOutlined MuiInput-colorNeutral MuiInput-sizeSm MuiInput-formControl css-uwg02d\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input id=\":R3elalj59l6kud6:\" type=\"number\" class=\"MuiInput-input css-fqt4w4\" value=\"8\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiInput-endDecorator css-tob0ta\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-body-xs css-wsc68b\">px"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button tabindex=\"-1\" class=\"MuiIconButton-root Mui-disabled MuiIconButton-variantPlain MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1vgb0z0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSm css-65w9j1\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ReplayRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 5V2.21c0-.45-.54-.67-.85-.35l-3.8 3.79c-.2.2-.2.51 0 .71l3.79 3.79c.32.31.86.09.86-.36V7c3.73 0 6.68 3.42 5.86 7.29-.47 2.27-2.31 4.1-4.57 4.57-3.57.75-6.75-1.7-7.23-5.01-.07-.48-.49-.85-.98-.85-.6 0-1.08.53-1 1.13.62 4.39 4.8 7.64 9.53 6.72 3.12-.61 5.63-3.12 6.24-6.24C20.84 9.48 16.94 5 12 5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormHelperText-root css-ovcyks\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h3 id=\"icon-button-2\">Icon Button<a aria-labelledby=\"icon-button-2\" class=\"anchor-link\" href=\"#icon-button-2\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"icon-button-2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"css-r6dqg1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"IconButtonVariables\" class=\"css-1og87pl\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div id=\"demo-:Rk59l6kud6:\" class=\"css-1tqnzfd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-t6lbop\" tabindex=\"-1\" type=\"button\" aria-label=\"A generic container that is programmatically focused to test keyboard navigation of our components.\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1n780lk\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-876u7n\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1dl3sot\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiIconButton-root MuiIconButton-variantPlain MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1vgb0z0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"FavoriteBorderIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-nd3o6\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-jsx\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">IconButton"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">FavoriteBorder <span class=\"token punctuation\">/&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">IconButton<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiSheet-root MuiSheet-variantPlain MuiSheet-colorNeutral css-lkarvp\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiList-root MuiList-vertical MuiList-variantPlain MuiList-colorNeutral MuiList-sizeMd css-13nh845\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-17k7nvu\" data-first-child=\"\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body-md css-1ohfyur\">CSS variables"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button aria-label=\"Reset all\" class=\"MuiIconButton-root MuiIconButton-variantOutlined MuiIconButton-colorPrimary MuiIconButton-sizeSm css-xz2pcu\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeXl2 css-l6vif8\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ReplayRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 5V2.21c0-.45-.54-.67-.85-.35l-3.8 3.79c-.2.2-.2.51 0 .71l3.79 3.79c.32.31.86.09.86-.36V7c3.73 0 6.68 3.42 5.86 7.29-.47 2.27-2.31 4.1-4.57 4.57-3.57.75-6.75-1.7-7.23-5.01-.07-.48-.49-.85-.98-.85-.6 0-1.08.53-1 1.13.62 4.39 4.8 7.64 9.53 6.72 3.12-.61 5.63-3.12 6.24-6.24C20.84 9.48 16.94 5 12 5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-horizontal css-zwz8tn\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-cyk6x5\" data-last-child=\"\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormControl-root MuiFormControl-vertical MuiFormControl-sizeMd css-1h5ao69\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<label for=\":R3elalk59l6kud6:\" id=\":R3elalk59l6kud6:-label\" class=\"MuiFormLabel-root css-8pv1g3\">--IconButton-size"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiInput-root MuiInput-variantOutlined MuiInput-colorNeutral MuiInput-sizeSm MuiInput-formControl css-uwg02d\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<input id=\":R3elalk59l6kud6:\" type=\"number\" class=\"MuiInput-input css-fqt4w4\" value=\"36\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiInput-endDecorator css-tob0ta\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-body-xs css-wsc68b\">px"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button tabindex=\"-1\" class=\"MuiIconButton-root Mui-disabled MuiIconButton-variantPlain MuiIconButton-colorNeutral MuiIconButton-sizeMd css-1vgb0z0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSm css-65w9j1\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ReplayRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 5V2.21c0-.45-.54-.67-.85-.35l-3.8 3.79c-.2.2-.2.51 0 .71l3.79 3.79c.32.31.86.09.86-.36V7c3.73 0 6.68 3.42 5.86 7.29-.47 2.27-2.31 4.1-4.57 4.57-3.57.75-6.75-1.7-7.23-5.01-.07-.48-.49-.85-.98-.85-.6 0-1.08.53-1 1.13.62 4.39 4.8 7.64 9.53 6.72 3.12-.61 5.63-3.12 6.24-6.24C20.84 9.48 16.94 5 12 5\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiFormHelperText-root css-ovcyks\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"accessibility\">Accessibility<a aria-labelledby=\"accessibility\" class=\"anchor-link\" href=\"#accessibility\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"accessibility\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>All Buttons must have a meaningful <a href=\"https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-label\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>aria-label"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "so their purpose can be understood by users who require assistive technology."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>This is especially important for <a href=\"#icon-button\">Icon Buttons because they don't contain any text."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "For example, an Icon Button that displays a <code>&lt;FavoriteBorder /&gt; icon might have a label that looks like this:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-js\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">IconButton <span class=\"token attr-name\">aria-label<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"Add to favorites<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;<span class=\"token class-name\">FavoriteBorder <span class=\"token punctuation\">/&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/<span class=\"token class-name\">IconButton<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button data-ga-event-category=\"code\" data-ga-event-action=\"copy-click\" aria-label=\"Copy the code\" class=\"MuiCode-copy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copy-icon\" xlink:href=\"#copy-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#copied-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiCode-copyKeypress\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>(or $keyC<span>)"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"anatomy\">Anatomy<a aria-labelledby=\"anatomy\" class=\"anchor-link\" href=\"#anatomy\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"anatomy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>The Button component is composed of a single root <code>&lt;button&gt; element that wraps around its contents:"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCode-root\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<pre><code class=\"language-html\"><span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;button <span class=\"token attr-name\">class<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"MuiButton-root<span class=\"token punctuation\">\" <span class=\"token attr-name\">type<span class=\"token attr-value\"><span class=\"token punctuation attr-equals\">=<span class=\"token punctuation\">\"button<span class=\"token punctuation\">\"<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token comment\">&lt;!-- Button contents --&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"token tag\"><span class=\"token tag\"><span class=\"token punctuation\">&lt;/button<span class=\"token punctuation\">&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button data-ga-event-category=\"code\" data-ga-event-action=\"copy-click\" aria-label=\"Copy the code\" class=\"MuiCode-copy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copy-icon\" xlink:href=\"#copy-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#copied-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiCode-copyKeypress\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>(or $keyC<span>)"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"unstyled\">Unstyled<a aria-labelledby=\"unstyled\" class=\"anchor-link\" href=\"#unstyled\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"unstyled\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<aside class=\"MuiCallout-root MuiCallout-success\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ContentCopyRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use class=\"MuiCode-copied-icon\" xlink:href=\"#success-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiCallout-content\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a href=\"/base-ui/\">Base UI provides a headless (\"unstyled\") version of this <a href=\"/base-ui/react-button/\">React Button component. Try it if you need more flexibility in customization and a smaller bundle size."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"markdown-body css-en00sx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<h2 id=\"api\">API<a aria-labelledby=\"api\" class=\"anchor-link\" href=\"#api\" tabindex=\"-1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#anchor-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button title=\"Post a comment\" class=\"comment-link\" data-feedback-hash=\"api\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<use xlink:href=\"#comment-link-icon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p>See the documentation below for a complete reference to all of the props and classes available to the components mentioned here."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a href=\"/joy-ui/api/button/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>&lt;Button /&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a href=\"/joy-ui/api/icon-button/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<code>&lt;IconButton /&gt;"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<footer class=\"MuiStack-root css-1abi6xj\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-28r57m\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiButton-root MuiButton-outlined MuiButton-outlinedPrimary MuiButton-sizeSmall MuiButton-outlinedSizeSmall MuiButton-disableElevation MuiButton-root MuiButton-outlined MuiButton-outlinedPrimary MuiButton-sizeSmall MuiButton-outlinedSizeSmall MuiButton-disableElevation css-1ta7zwo\" tabindex=\"0\" href=\"https://github.com/mui/material-ui/edit/master/docs/data/joy/components/button/button.md\" target=\"_blank\" rel=\"noopener nofollow\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startIcon MuiButton-iconSizeSmall css-16rzsu1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-do1tfz\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"GitHubIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M12 1.27a11 11 0 00-3.48 21.46c.55.09.73-.28.73-.55v-1.84c-3.03.64-3.67-1.46-3.67-1.46-.55-1.29-1.28-1.65-1.28-1.65-.92-.65.1-.65.1-.65 1.1 0 1.73 1.1 1.73 1.1.92 1.65 2.57 1.2 3.21.92a2 2 0 01.64-1.47c-2.47-.27-5.04-1.19-5.04-5.5 0-1.1.46-2.1 1.2-2.84a3.76 3.76 0 010-2.93s.91-.28 3.11 1.1c1.8-.49 3.7-.49 5.5 0 2.1-1.38 3.02-1.1 3.02-1.1a3.76 3.76 0 010 2.93c.83.74 1.2 1.74 1.2 2.94 0 4.21-2.57 5.13-5.04 5.4.45.37.82.92.82 2.02v3.03c0 .27.1.64.73.55A11 11 0 0012 1.27\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Edit this page"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-csffzd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body2 css-9q8mec\" id=\"feedback-message\">Was this page helpful?"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInfo MuiIconButton-sizeMedium css-dgcsjh\" tabindex=\"0\" type=\"button\" aria-pressed=\"false\" aria-label=\"Yes\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1bdxnx3\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ThumbUpAltRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M13.12 2.06 7.58 7.6c-.37.37-.58.88-.58 1.41V19c0 1.1.9 2 2 2h9c.8 0 1.52-.48 1.84-1.21l3.26-7.61C23.94 10.2 22.49 8 20.34 8h-5.65l.95-4.58c.1-.5-.05-1.01-.41-1.37-.59-.58-1.53-.58-2.11.01M3 21c1.1 0 2-.9 2-2v-8c0-1.1-.9-2-2-2s-2 .9-2 2v8c0 1.1.9 2 2 2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<button class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInfo MuiIconButton-sizeMedium css-dgcsjh\" tabindex=\"0\" type=\"button\" aria-pressed=\"false\" aria-label=\"No\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1bdxnx3\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ThumbDownAltRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"m10.88 21.94 5.53-5.54c.37-.37.58-.88.58-1.41V5c0-1.1-.9-2-2-2H6c-.8 0-1.52.48-1.83 1.21L.91 11.82C.06 13.8 1.51 16 3.66 16h5.65l-.95 4.58c-.1.5.05 1.01.41 1.37.59.58 1.53.58 2.11-.01M21 3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2s2-.9 2-2V5c0-1.1-.9-2-2-2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-fullWidth css-10d9ljd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-t71n5l\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation css-6zntoz\" tabindex=\"0\" href=\"/joy-ui/react-autocomplete/\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startIcon MuiButton-iconSizeSmall css-16rzsu1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ChevronLeftIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M15.41 7.41 14 6l-6 6 6 6 1.41-1.41L10.83 12z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Autocomplete"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation css-6zntoz\" tabindex=\"0\" href=\"/joy-ui/react-button-group/\">Button Group<span class=\"MuiButton-endIcon MuiButton-iconSizeSmall css-kcxyz4\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ChevronRightIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<hr class=\"MuiDivider-root MuiDivider-fullWidth css-10d9ljd\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-dpal3j\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-13j1pu0\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-jojn6a\" href=\"https://mui.com/\" aria-label=\"Go to homepage\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 117 36\" fill=\"none\" height=\"24\" width=\"72\" class=\"css-unwszx\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M11.59 10.73.75 4.43a.5.5 0 0 0-.75.44V22.4c0 .18.1.34.25.43l4.05 2.38a.5.5 0 0 0 .75-.43V13.34a.2.2 0 0 1 .3-.17l6.25 3.58a2 2 0 0 0 2-.01l6.1-3.57a.2.2 0 0 1 .3.17v5.6a1 1 0 0 1-.48.85l-6.28 3.86a.5.5 0 0 0-.24.43v5.64c0 .18.09.34.23.43l8.23 5.2a2 2 0 0 0 2.1.02l10.46-6.2a2 2 0 0 0 .98-1.73V16.63a.5.5 0 0 0-.76-.43l-3.31 2a2 2 0 0 0-.97 1.7v5.43a.5.5 0 0 1-.25.43l-6.19 3.65a2 2 0 0 1-2.04-.01l-3.33-2a.5.5 0 0 1-.02-.84l6.02-3.97a2 2 0 0 0 .9-1.67V4.87a.5.5 0 0 0-.75-.43l-10.7 6.29a2 2 0 0 1-2.01 0Z\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M35 5.36v3.42a2 2 0 0 1-.94 1.7l-3.3 2.05a.5.5 0 0 1-.76-.43V8.52a2 2 0 0 1 1-1.73l3.25-1.86a.5.5 0 0 1 .75.43Z\" fill=\"#007FFF\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M50.38 26.5V8.3h4.5l7.56 10.5-3.32-.02L66.7 8.3h4.44v18.2H66.2v-5.02c0-1.49.03-2.86.1-4.1.07-1.27.21-2.55.42-3.83l.52 1.61-5.64 7.28h-1.72l-5.62-7.35.58-1.54c.2 1.25.34 2.5.41 3.75.07 1.24.1 2.64.1 4.18v5.02h-4.96Zm34.88.16c-1.77 0-3.34-.35-4.7-1.04a7.87 7.87 0 0 1-3.18-2.89 7.92 7.92 0 0 1-1.11-4.19V8.3h5.2v10.09c0 .76.16 1.43.49 2 .33.57.78 1.01 1.35 1.33a4 4 0 0 0 1.95.46c.76 0 1.44-.15 2.03-.46.6-.32 1.07-.76 1.4-1.33.35-.57.52-1.24.52-2V8.3h5.05v10.24a7.78 7.78 0 0 1-4.3 7.08c-1.33.69-2.9 1.04-4.7 1.04Zm14.41-.16v-4.32h4.19v-9.56h-4.19V8.3h13.5v4.32H109v9.56h4.16v4.32h-13.5Z\" fill=\"currentColor\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-4712ze\">•"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-16fsg5i\" href=\"https://mui.com/blog/\" target=\"_blank\" rel=\"noopener noreferrer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-1s16jae\">Blog <svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1yls13q\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ArrowOutwardRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M6 7c0 .55.45 1 1 1h7.59l-8.88 8.88c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L16 9.41V17c0 .55.45 1 1 1s1-.45 1-1V7c0-.55-.45-1-1-1H7c-.55 0-1 .45-1 1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-4712ze\">•"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-16fsg5i\" href=\"https://mui.com/store/\" target=\"_blank\" rel=\"noopener noreferrer\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-1s16jae\">Store <svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-1yls13q\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"ArrowOutwardRoundedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M6 7c0 .55.45 1 1 1h7.59l-8.88 8.88c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L16 9.41V17c0 .55.45 1 1 1s1-.45 1-1V7c0-.55-.45-1-1-1H7c-.55 0-1 .45-1 1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-1mzerio\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeSmall css-1p6m098\" tabindex=\"0\" target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://mui.com/feed/blog/rss.xml\" aria-label=\"RSS Feed\" title=\"RSS Feed\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-opaoez\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"RssFeedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<circle cx=\"6.18\" cy=\"17.82\" r=\"2.18\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56m0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeSmall css-1p6m098\" tabindex=\"0\" target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://twitter.com/MUI_hq\" aria-label=\"twitter\" title=\"X\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-opaoez\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"XIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeSmall css-1p6m098\" tabindex=\"0\" target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://www.youtube.com/@MUI_hq\" aria-label=\"YouTube\" title=\"YouTube\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-opaoez\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"YouTubeIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeSmall css-1p6m098\" tabindex=\"0\" target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://mui.com/r/discord/\" aria-label=\"Discord\" title=\"Discord\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-opaoez\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M20.32 4.37a19.8 19.8 0 0 0-4.89-1.52.07.07 0 0 0-.08.04c-.2.38-.44.87-.6 1.25a18.27 18.27 0 0 0-5.5 0c-.16-.4-.4-.87-.6-1.25a.08.08 0 0 0-.09-.04 19.74 19.74 0 0 0-4.88 1.52.07.07 0 0 0-.04.03A20.26 20.26 0 0 0 .1 18.06a.08.08 0 0 0 .03.05 19.9 19.9 0 0 0 6 3.03.08.08 0 0 0 .08-.02c.46-.63.87-1.3 1.22-2a.08.08 0 0 0-.04-.1 13.1 13.1 0 0 1-1.87-.9.08.08 0 0 1 0-.12l.36-.3a.07.07 0 0 1 .08 0 14.2 14.2 0 0 0 12.06 0 .07.07 0 0 1 .08 0l.37.3a.08.08 0 0 1 0 .12 12.3 12.3 0 0 1-1.88.9.08.08 0 0 0-.04.1c.36.7.78 1.36 1.23 2a.08.08 0 0 0 .08.02c1.96-.6 3.95-1.52 6-3.03a.08.08 0 0 0 .04-.05c.5-5.18-.84-9.68-3.55-13.66a.06.06 0 0 0-.03-.03zM8.02 15.33c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.96 2.42-2.16 2.42zm7.97 0c-1.18 0-2.15-1.08-2.15-2.42 0-1.33.95-2.42 2.15-2.42 1.22 0 2.18 1.1 2.16 2.42 0 1.34-.94 2.42-2.16 2.42Z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<nav aria-label=\"Page table of contents\" class=\"css-ly1r2q\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1yaq0io\" href=\"https://war.ukraine.ua/support-ukraine/\" target=\"_blank\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1yuqj86\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-spfw6s\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiBox-root css-1u18uw9\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-caption css-193blm8\">MUI stands in solidarity with Ukraine."
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<p class=\"MuiTypography-root MuiTypography-body1 css-967ein\">Contents"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"MuiTypography-root MuiTypography-body1 css-utqcip\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#introduction\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Introduction"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#basics\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Basics"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"css-17mrx6g\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#disabled\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Disabled"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#loading\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Loading"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#customization\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Customization"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"css-17mrx6g\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#variants\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Variants"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#sizes\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Sizes"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#colors\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Colors"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#decorators\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Decorators"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#loading-indicator\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Loading indicator"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#loading-position\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Loading position"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#link-button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Link Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#file-upload\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>File upload"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#icon-button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Icon Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#css-variables-playground\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>CSS variables playground"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<ul class=\"css-17mrx6g\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#button\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-1p623o5\" href=\"/joy-ui/react-button/#icon-button-2\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Icon Button"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#accessibility\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Accessibility"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#anatomy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Anatomy"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<li>"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-vpo3ro\" href=\"/joy-ui/react-button/#unstyled\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span>Unstyled"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-14m5so\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a class=\"MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeSmall MuiButton-textSizeSmall MuiButton-disableElevation css-baozuo\" tabindex=\"0\" href=\"/material-ui/discover-more/backers/\" target=\"_blank\" rel=\"noopener nofollow\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiButton-startIcon MuiButton-iconSizeSmall css-16rzsu1\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<svg class=\"MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv\" focusable=\"false\" aria-hidden=\"true\" viewBox=\"0 0 24 24\" data-testid=\"DiamondOutlinedIcon\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<path d=\"M19 3H5L2 9l10 12L22 9zM9.62 8l1.5-3h1.76l1.5 3zM11 10v6.68L5.44 10zm2 0h5.56L13 16.68zm6.26-2h-2.65l-1.5-3h2.65zM6.24 5h2.65l-1.5 3H4.74z\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "Diamond sponsors"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<div class=\"MuiStack-root css-18zsr3k\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-ga-event-category=\"sponsor\" data-ga-event-action=\"docs-premium\" data-ga-event-label=\"octopus.com\" href=\"https://octopus.com/?utm_source=materialui&amp;utm_medium=referral\" rel=\"noopener sponsored\" target=\"_blank\" class=\"css-7fdl0i\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<img class=\"MuiBox-root css-kihmet\" src=\"/static/sponsors/octopus-light.svg\" alt=\"octopus\" title=\"Repeatable, reliable deployments\" loading=\"lazy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-ga-event-category=\"sponsor\" data-ga-event-action=\"docs-premium\" data-ga-event-label=\"doit.com\" href=\"https://www.doit.com/flexsave/?utm_source=materialui&amp;utm_medium=referral\" rel=\"noopener sponsored\" target=\"_blank\" class=\"css-7fdl0i\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<img class=\"MuiBox-root css-18iki3b\" src=\"/static/sponsors/doit-light.svg\" alt=\"doit\" title=\"Management Platform for Google Cloud and AWS\" loading=\"lazy\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<a data-no-markdown-link=\"true\" class=\"MuiTypography-root MuiTypography-inherit MuiLink-root MuiLink-underlineNone css-q21xj2\" href=\"/material-ui/discover-more/backers/#diamond-sponsors\">"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-caption css-1pkjr9\">Become a Diamond sponsor"
  },
  {
    "metadata": {
      "source": "https://mui.com/joy-ui/react-button/",
      "content": "HTML Element"
    },
    "pageContent": "<span class=\"MuiTypography-root MuiTypography-caption css-2dc6k2\">One spot left!"
  }
]